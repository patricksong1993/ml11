function[majority_value] = majority_value(binary_targets)

majority_value = mode(binary_targets);

end