function c = inc_typicality(c)
    c.typicality = c.typicality + 1;
end